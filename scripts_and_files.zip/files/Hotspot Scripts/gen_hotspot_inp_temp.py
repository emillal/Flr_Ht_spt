import numpy as np
import h5py
import os

def generate_desc(macros, desc_path, chip_width, chip_height, connectivity_matrix):
    with open(desc_path, 'w') as f:
        f.write("# block name\tarea\tmin aspect ratio\tmax aspect ratio\trotable\n")
        for j, (x, y, width, height) in enumerate(macros):
            # Scale down macro dimensions if necessary
            x_scaled = x * (chip_width / max(x + width for x, y, width, height in macros))
            y_scaled = y * (chip_height / max(y + height for x, y, width, height in macros))
            width_scaled = width * (chip_width / max(x + width for x, y, width, height in macros))
            height_scaled = height * (chip_height / max(y + height for x, y, width, height in macros))
            
            if x_scaled + width_scaled > chip_width or y_scaled + height_scaled > chip_height:
                print(f"Macro {j} details: x={x_scaled}, y={y_scaled}, width={width_scaled}, height={height_scaled}")
                print(f"Macro {j} details: chip_width={chip_width}, chip_height={chip_height}")
                raise ValueError(f"Macro {j} extends beyond chip boundaries!")

            area = width_scaled * height_scaled * 1e-6  # converting to m^2
            f.write(f"macro_{j}\t{area:.6e}\t1\t2\t1\n")

        # Add connectivity information
        f.write("\n# connectivity\n")
        for i in range(len(macros)):
            for j in range(len(macros)):
                if connectivity_matrix[i, j] != 0:
                    f.write(f"macro_{i}\tmacro_{j}\t{connectivity_matrix[i, j]}\n")

def generate_power_file(power_density, macros, power_file_path):
    with open(power_file_path, 'w') as f:
        for j, (x, y, width, height) in enumerate(macros):
            avg_power = np.mean(power_density[x:x + width, y:y + height])
            f.write(f"macro_{j}\t{avg_power:.6f}\n")

def create_config_file(config_path, chip_width, chip_height):
    config_content = f"""
# thermal model parameters

# chip specs
# chip thickness in meters (only used if LCF is not specified)
-t_chip 0.00015
# chip default thermal conductivity in W/(m-K) (overrided by default material)
-k_chip 130.0
# chip volumetric heat capacity in J/(m^3-K) (overrided by default material)
-p_chip 1630300

# chip dimensions
-chip_width {chip_width}
-chip_height {chip_height}

# heat sink specs
# convection capacitance in J/K
-c_convec 140.4
# convection resistance in K/W
-r_convec 1.042
# heatsink side in meters
-s_sink 0.06
# heatsink thickness in meters
-t_sink 0.0069
# heatsink thermal conductivity in W/(m-K) (overrided by heat sink material)
-k_sink 400.0
# heatsink volumetric heat capacity in J/(m^3-K) (overrided by heat sink material)
-p_sink 3.55e6

# heat spreader specs
# spreader side in meters
-s_spreader 0.03
# spreader thickness in meters
-t_spreader 0.001
# heat spreader thermal conductivity in W/(m-K) (overrided by spreader material)
-k_spreader 400.0
# heat spreader volumetric heat capacity in J/(m^3-K) (overrided by spreader material)
-p_spreader 3.55e6

# interface material specs
# interface material thickness in meters
-t_interface 2.0e-05
# interface material thermal conductivity in W/(m-K) (overrided by interface material)
-k_interface 4.0
# interface material volumetric heat capacity in J/(m^3-K) (overrided by interface material)
-p_interface 4.0e6

# others
# ambient temperature in kelvin
-ambient 318.15
# initial temperature (kelvin) if not from file
-init_temp 318.15
# model type - block or grid
-model_type block

# grid model specific parameters
# grid resolution - no. of rows
-grid_rows 32
# grid resolution - no. of cols
-grid_cols 32
# layer configuration from file
-grid_layer_file (null)

# annealing parameters
# initial acceptance probability
-P0 0.99
# average change (delta) in cost
-Davg 1
# no. of moves to try in each step
-Kmoves 7
# ratio for the cooling schedule
-Rcool 0.99
# ratio of rejects at which to stop annealing
-Rreject 0.99
# absolute max no. of annealing steps
-Nmax 1000

# weights for the metric: lambdaA * A + lambdaT * T + lambdaW * W
# weight for the area term
-lambdaA 5.0e+06
# weight for the temperature term
-lambdaT 1
# weight for the wire length term
-lambdaW 350
"""
    with open(config_path, 'w') as f:
        f.write(config_content.strip() + '\n')

def main(h5_file, output_dir):
    with h5py.File(h5_file, 'r') as f:
        macro_details = [np.array(f['macro_details'][i]).reshape(-1, 4) for i in range(len(f['macro_details']))]
        power_density = np.asarray(f['power_density'])
        connectivity_matrices = [np.array(f['connectivity'][i]) for i in range(len(f['connectivity']))]

    # Adjust these values based on expected macro sizes
    chip_width = 0.5  # Adjusted chip width to fit scaled macros
    chip_height = 0.5  # Adjusted chip height to fit scaled macros

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    config_path = os.path.join(output_dir, 'hotspot.config')
    create_config_file(config_path, chip_width, chip_height)

    for i, macros in enumerate(macro_details):
        desc_path = os.path.join(output_dir, f'floorplan_{i}.desc')
        power_file_path = os.path.join(output_dir, f'power_{i}.p')
        output_flp_path = os.path.join(output_dir, f'output_{i}.flp')

        generate_desc(macros, desc_path, chip_width, chip_height, connectivity_matrices[i])
        generate_power_file(power_density[i], macros, power_file_path)

if __name__ == '__main__':
    h5_file = 'floorplan_data.h5'
    output_dir = 'hotspot_outputs'
    main(h5_file, output_dir)

