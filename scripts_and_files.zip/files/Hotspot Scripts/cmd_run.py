import os
import subprocess


num_files = 10000  # number of input files
output_dir = 'outputs'
os.makedirs(output_dir, exist_ok=True)

for i in range(num_files):
    floorplan_file = f'floorplan_{i}.desc'
    power_file = f'power_{i}.p'
    output_file = os.path.join(output_dir, f'output_{i}.flp')
    
    command = f'../hotfloorplan -c hotspot.config -f {floorplan_file} -p {power_file} -o {output_file}'
    
    # Run command
    subprocess.run(command, shell=True)

