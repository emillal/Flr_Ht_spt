import numpy as np
import os
import h5py
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def generate_color_dict(num_macros):
    np.random.seed(0)  # For reproducibility
    colors = np.random.randint(0, 256, size=(num_macros, 3))
    color_dict = {i + 1: colors[i] for i in range(num_macros)}  # Indices start from 1
    return color_dict

def decode_floorplan_data(floorplan, macro_details, color_dict):
    H, W = floorplan.shape
    background_color = np.array([255, 255, 255])  # White for background

    # Initialize output
    out = np.zeros((3, H, W))

    for idx, (x, y, width, height) in enumerate(macro_details):
        macro_index = idx + 1
        color = color_dict.get(macro_index, background_color)
        out[:, x:x + width, y:y + height] = color[:, np.newaxis, np.newaxis]

    # Fill the background
    out[:, floorplan == 0] = background_color[:, np.newaxis]

    return out

def plot_feature_map(feature_map, title):
    plt.imshow(feature_map, cmap='hot', interpolation='nearest')
    plt.title(title)
    im_ratio = feature_map.shape[0] / feature_map.shape[1]
    plt.colorbar(fraction=0.047 * im_ratio)

def plot_binary_hotspot_map(hotspot_map, title):
    plt.imshow(hotspot_map, cmap='gray', interpolation='nearest')
    plt.title(title)

def main():
    plt.rcParams['figure.figsize'] = (15.0, 10.0)  # Set default size of plots
    plt.rcParams['image.interpolation'] = 'nearest'
    plt.rcParams['image.cmap'] = 'gray'

    data = {}
    data_file = os.path.join(os.getcwd(), "floorplan_data.h5")

    if not os.path.exists(data_file):
        print(f"Error: File '{data_file}' not found.")
        return

    with h5py.File(data_file, 'r') as f:
        data['floorplans'] = np.asarray(f['data'])
        data['num_macros'] = np.asarray(f['num_macros'])
        data['power_density'] = np.asarray(f['power_density'])
        data['switching_activity'] = np.asarray(f['switching_activity'])
        data['thermal_conductivity'] = np.asarray(f['thermal_conductivity'])
        data['binary_hotspot'] = np.asarray(f['binary_hotspot'])
        macro_details = np.asarray(f['macro_details'])  # Now stored as a padded 3D array

    num_samples = len(data['floorplans'])
    num_macros = max(data['num_macros'])
    color_dict = generate_color_dict(num_macros)

    num_images = min(3, num_samples)  # Plot up to 3 images

    # Creating a single figure for X (floorplans and feature maps)
    plt.figure(figsize=(20, 20))

    for n in range(num_images):
        valid_macros = data['num_macros'][n]
        macros = macro_details[n, :valid_macros]  # Extract only valid macro entries

        decoded_image = decode_floorplan_data(data['floorplans'][n], macros, color_dict)
        decoded_image = np.swapaxes(decoded_image, 0, 1)  # (H, 3, W)
        decoded_image = np.swapaxes(decoded_image, 1, 2)  # (H, W, 3)

        plt.subplot(num_images, 4, 4 * n + 1)
        plt.imshow(decoded_image.astype('uint8'))
        plt.title(f"Floorplan {n + 1}")

        plt.subplot(num_images, 4, 4 * n + 2)
        plot_feature_map(data['power_density'][n], f"Power Density {n + 1}")

        plt.subplot(num_images, 4, 4 * n + 3)
        plot_feature_map(data['switching_activity'][n], f"Switching Activity {n + 1}")

        plt.subplot(num_images, 4, 4 * n + 4)
        plot_feature_map(data['thermal_conductivity'][n], f"Thermal Conductivity {n + 1}")

    plt.tight_layout(pad=2.0, w_pad=1.0, h_pad=1.0)
    plt.savefig("X_floorplan_feature_maps.jpg")
    plt.savefig("X_floorplan_feature_maps.eps")
    plt.close()

    # Creating a single figure for Y (binary hotspot maps)
    plt.figure(figsize=(15, 5))

    for n in range(num_images):
        print(f"Binary Hotspot Map {n + 1} Values: {np.unique(data['binary_hotspot'][n])}") 
        plt.subplot(1, num_images, n + 1)
        plot_binary_hotspot_map(data['binary_hotspot'][n], f"Binary Hotspot {n + 1}")
        
    plt.tight_layout(pad=2.0, w_pad=1.0, h_pad=1.0)
    plt.savefig("Y_binary_hotspot_maps.jpg")
    plt.savefig("Y_binary_hotspot_maps.eps")
    plt.close()

if __name__ == '__main__':
    main()

